package com.sunsoft.eclipselink.DAO;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.sunsoft.eclipselink.bean.Author;

public class CRUD_Service {
	
	static EntityManagerFactory emfactory=Persistence.createEntityManagerFactory("Eclipselink_JPA");
	static EntityManager entitymanager=emfactory.createEntityManager();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CRUD_Service crud_serviceObj=new CRUD_Service();
		

	/*
	  	Author authorObj1=new Author();
		authorObj1.setAuthorId(1);
		authorObj1.setFirstName("Manish");
		authorObj1.setMiddleName("Raj ");
		authorObj1.setLastName("Nigam");
		authorObj1.setPhoneNo(12345);
		crud_serviceObj.InsertIntoAuthorDB(authorObj1);
		
		Author authorObj=new Author();
		authorObj.setAuthorId(2);
		authorObj.setFirstName("Yashika");
		authorObj.setMiddleName("K");
		authorObj.setLastName("Srivastava");
		authorObj.setPhoneNo(56984);
		crud_serviceObj.InsertIntoAuthorDB(authorObj);
		}

	void InsertIntoAuthorDB(Author authorObj1) {
		entitymanager.getTransaction().begin();
		entitymanager.persist(authorObj1);
		entitymanager.getTransaction().commit();
}*/

	/*------------------------------------getDetails of author----------------------------------
	 Author authorObj=crud_serviceObj.getAuthorDetails(1);
	 
	System.out.println("author id=" + authorObj.getAuthorId());
	System.out.println("author firstName=" + authorObj.getFirstName());
	System.out.println("author middleName=" + authorObj.getMiddleName());
	System.out.println("author lastName=" + authorObj.getLastName());
	System.out.println("author phoneNo=" + authorObj.getPhoneNo());
	
	}
	Author getAuthorDetails(int authorId)
	{
		Author author1=entitymanager.find(Author.class, authorId);
		return author1;
	}*/
	
		/*------------------------delete record successfully
		crud_serviceObj.deleteAuthorData(2);
		System.out.println("Deleted the Author record successfully");
		
	}
	
	void deleteAuthorData(int authorId)
	{
		entitymanager.getTransaction().begin();
		Author author1=entitymanager.find(Author.class, authorId);
		entitymanager.remove(author1);
		entitymanager.getTransaction().commit();
	}*/
	
		
		//-----------Update author record--------
	crud_serviceObj.UpdateAuthor(1,56321);
	System.out.println("Author Data update successfully");
	}
	
	 void UpdateAuthor(int authorId, int phoneNo){
	
		 entitymanager.getTransaction().begin();
		Author author1=entitymanager.find(Author.class, authorId);
		author1.setPhoneNo(phoneNo);
		entitymanager.getTransaction().commit();
	
	 }
	
	
	
	}	
